var searchData=
[
  ['max_5fndef_5flength',['max_ndef_length',['../structndef__info__t.html#aceab07510d20e6cb2fa440c5c425e84d',1,'ndef_info_t']]]
];
