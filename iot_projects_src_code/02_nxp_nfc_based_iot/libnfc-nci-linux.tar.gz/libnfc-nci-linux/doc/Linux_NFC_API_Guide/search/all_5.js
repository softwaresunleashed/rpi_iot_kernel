var searchData=
[
  ['handle',['handle',['../structnfc__tag__info__t.html#a85985ecd5d8effd2ab8c1c71a0b7729a',1,'nfc_tag_info_t']]],
  ['handover_5fcps_5factivating',['HANDOVER_CPS_ACTIVATING',['../linux__nfc__api_8h.html#a7c6b0ba3e307e06fe009338c6899c0aba70957c19fd225cba4c6d070126292561',1,'linux_nfc_api.h']]],
  ['handover_5fcps_5factive',['HANDOVER_CPS_ACTIVE',['../linux__nfc__api_8h.html#a7c6b0ba3e307e06fe009338c6899c0aba66e02c11c38536728b1503a0f43f090b',1,'linux_nfc_api.h']]],
  ['handover_5fcps_5finactive',['HANDOVER_CPS_INACTIVE',['../linux__nfc__api_8h.html#a7c6b0ba3e307e06fe009338c6899c0aba5a5e7ec10ff5fbf9644956f020b676ee',1,'linux_nfc_api.h']]],
  ['handover_5fcps_5funknown',['HANDOVER_CPS_UNKNOWN',['../linux__nfc__api_8h.html#a7c6b0ba3e307e06fe009338c6899c0abadbf07c21a7b7fd2ee679548f303e6089',1,'linux_nfc_api.h']]],
  ['handover_5ftype_5fble',['HANDOVER_TYPE_BLE',['../linux__nfc__api_8h.html#a8b59b6a55393811dd22637a66cfcfbf6a2bf23c0e1b198f614921aa72f5c7894f',1,'linux_nfc_api.h']]],
  ['handover_5ftype_5fbt',['HANDOVER_TYPE_BT',['../linux__nfc__api_8h.html#a8b59b6a55393811dd22637a66cfcfbf6a9699420a1ddf33d933533a0829eaa41d',1,'linux_nfc_api.h']]],
  ['handover_5ftype_5funknown',['HANDOVER_TYPE_UNKNOWN',['../linux__nfc__api_8h.html#a8b59b6a55393811dd22637a66cfcfbf6a4124dbf939a04836cd79b147a1521919',1,'linux_nfc_api.h']]],
  ['has_5fwifi',['has_wifi',['../structnfc__wifi__request__t.html#aed304d3ae9388b52a0781bbc76b5a241',1,'nfc_wifi_request_t']]]
];
