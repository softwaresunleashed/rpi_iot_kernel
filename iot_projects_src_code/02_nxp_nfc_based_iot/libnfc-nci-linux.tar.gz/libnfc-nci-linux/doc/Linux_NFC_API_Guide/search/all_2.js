var searchData=
[
  ['current_5fndef_5flength',['current_ndef_length',['../structndef__info__t.html#a599deceb00d4286b83343f8ad7313c2b',1,'ndef_info_t']]]
];
