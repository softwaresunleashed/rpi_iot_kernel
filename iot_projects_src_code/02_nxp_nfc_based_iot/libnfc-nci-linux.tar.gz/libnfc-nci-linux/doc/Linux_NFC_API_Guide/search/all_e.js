var searchData=
[
  ['target_5ftype_5ffelica',['TARGET_TYPE_FELICA',['../linux__nfc__api_8h.html#ab777e59956b9a4241dc9e0ebc4ac892a',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fiso14443_5f3a',['TARGET_TYPE_ISO14443_3A',['../linux__nfc__api_8h.html#ab5ef14a4bbe39ca91b84f9806a80905f',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fiso14443_5f3a_5f3b',['TARGET_TYPE_ISO14443_3A_3B',['../linux__nfc__api_8h.html#a7a63f883dd82c4d397c577932e411147',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fiso14443_5f3b',['TARGET_TYPE_ISO14443_3B',['../linux__nfc__api_8h.html#aa9bf0125db1eccd1abeac27268ed784c',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fiso14443_5f4',['TARGET_TYPE_ISO14443_4',['../linux__nfc__api_8h.html#af56d104a6280d313a7af87f6bd506dd9',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fiso15693',['TARGET_TYPE_ISO15693',['../linux__nfc__api_8h.html#a15d24472b7f54cc02ca3a45581caadf5',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fkovio_5fbarcode',['TARGET_TYPE_KOVIO_BARCODE',['../linux__nfc__api_8h.html#ac8b86ebf047a536f88f8278543dd7353',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fmifare_5fclassic',['TARGET_TYPE_MIFARE_CLASSIC',['../linux__nfc__api_8h.html#a264ed89b38167610d72872342c067147',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fmifare_5ful',['TARGET_TYPE_MIFARE_UL',['../linux__nfc__api_8h.html#a6ad905f83acdbdfdff0fb55c44426987',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fndef',['TARGET_TYPE_NDEF',['../linux__nfc__api_8h.html#a0000dadcbe739099a795c891aca5bca5',1,'linux_nfc_api.h']]],
  ['target_5ftype_5fndef_5fformatable',['TARGET_TYPE_NDEF_FORMATABLE',['../linux__nfc__api_8h.html#ad7718e7c754ad319ddba0728dd8a2e50',1,'linux_nfc_api.h']]],
  ['target_5ftype_5funknown',['TARGET_TYPE_UNKNOWN',['../linux__nfc__api_8h.html#a520342ae6a088fef28b07683d262424b',1,'linux_nfc_api.h']]],
  ['technology',['technology',['../structnfc__tag__info__t.html#ae86261692eb29257980f646402880367',1,'nfc_tag_info_t']]],
  ['tnfc_5fprotocol',['tNFC_PROTOCOL',['../linux__nfc__api_8h.html#a5bbdb860d0cd45c3077e27bbcf0abc5f',1,'linux_nfc_api.h']]],
  ['type',['type',['../structnfc__btoob__pairing__t.html#adba44a81c741d47f12c4bd3ea049434b',1,'nfc_btoob_pairing_t']]]
];
