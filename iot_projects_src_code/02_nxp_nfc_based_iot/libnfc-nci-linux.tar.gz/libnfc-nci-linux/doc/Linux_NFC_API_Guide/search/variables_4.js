var searchData=
[
  ['handle',['handle',['../structnfc__tag__info__t.html#a85985ecd5d8effd2ab8c1c71a0b7729a',1,'nfc_tag_info_t']]],
  ['has_5fwifi',['has_wifi',['../structnfc__wifi__request__t.html#aed304d3ae9388b52a0781bbc76b5a241',1,'nfc_wifi_request_t']]]
];
