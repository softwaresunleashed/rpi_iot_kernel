var searchData=
[
  ['wagcdifferentialwithopen1',['wAgcDifferentialWithOpen1',['../structnfc_factory___antenna___st___resp__t.html#a0a22b9d8ec7a8d152eb2356d00744f6d',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcdifferentialwithopen2',['wAgcDifferentialWithOpen2',['../structnfc_factory___antenna___st___resp__t.html#a3fa226f2bbaa63ddee5114e0cf3fc484',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcdifferentialwithopentolerance1',['wAgcDifferentialWithOpenTolerance1',['../structnfc_factory___antenna___st___resp__t.html#a77fc8e9a494cd41577488921bcc09471',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcdifferentialwithopentolerance2',['wAgcDifferentialWithOpenTolerance2',['../structnfc_factory___antenna___st___resp__t.html#a38b804f09a2f17a338929b8c180ba7b7',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcvalue',['wAgcValue',['../structnfc_factory___antenna___st___resp__t.html#aedd84f76c2867bb478ca1efb159b579b',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcvaluetolerance',['wAgcValueTolerance',['../structnfc_factory___antenna___st___resp__t.html#a1692a5500b2d10047572d484ca7bb5c2',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcvaluewithfixednfcld',['wAgcValuewithfixedNFCLD',['../structnfc_factory___antenna___st___resp__t.html#a4ae0eca169937000e789fd3c9a931bbf',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wagcvaluewithfixednfcldtolerance',['wAgcValuewithfixedNFCLDTolerance',['../structnfc_factory___antenna___st___resp__t.html#ac1e52d8d0d3e54c75322fc4f295f6163',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wifi',['wifi',['../structnfc__handover__request__t.html#a2b3132e8cfe22383656949f52ecc426d',1,'nfc_handover_request_t::wifi()'],['../structnfc__handover__select__t.html#a53e2e99c6ef26c85506a7cbbf183562b',1,'nfc_handover_select_t::wifi()']]],
  ['wtxdomeasuredrangemax',['wTxdoMeasuredRangeMax',['../structnfc_factory___antenna___st___resp__t.html#a6608e659575d07f604f5fcc960e174e7',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wtxdomeasuredrangemin',['wTxdoMeasuredRangeMin',['../structnfc_factory___antenna___st___resp__t.html#a91d114778912b4ab2859201513113eaf',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wtxdomeasuredtolerance',['wTxdoMeasuredTolerance',['../structnfc_factory___antenna___st___resp__t.html#a5ebf2d59db33ec18eefebfa25e5d84ea',1,'nfcFactory_Antenna_St_Resp_t']]],
  ['wtxdorawvalue',['wTxdoRawValue',['../structnfc_factory___antenna___st___resp__t.html#a9e104ecfc95b37892d939e03f16caf22',1,'nfcFactory_Antenna_St_Resp_t']]]
];
