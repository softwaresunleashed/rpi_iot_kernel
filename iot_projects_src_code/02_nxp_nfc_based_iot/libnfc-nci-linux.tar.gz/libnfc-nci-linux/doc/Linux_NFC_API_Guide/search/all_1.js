var searchData=
[
  ['bluetooth',['bluetooth',['../structnfc__handover__request__t.html#a4c573081e5a1b4e8375fe794b92fab6f',1,'nfc_handover_request_t::bluetooth()'],['../structnfc__handover__select__t.html#a217527ba221612e9f11e2c733877e218',1,'nfc_handover_select_t::bluetooth()']]]
];
