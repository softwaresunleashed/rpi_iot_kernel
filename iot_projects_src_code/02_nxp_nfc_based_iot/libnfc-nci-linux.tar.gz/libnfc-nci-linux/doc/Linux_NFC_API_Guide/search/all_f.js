var searchData=
[
  ['uid',['uid',['../structnfc__tag__info__t.html#ac78a89e30460f5223a824f75e82d4170',1,'nfc_tag_info_t']]],
  ['uid_5flength',['uid_length',['../structnfc__tag__info__t.html#a0c957c67c5b182ee182741cbd827fc11',1,'nfc_tag_info_t']]]
];
