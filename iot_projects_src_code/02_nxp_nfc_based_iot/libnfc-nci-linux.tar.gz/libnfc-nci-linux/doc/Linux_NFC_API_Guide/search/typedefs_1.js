var searchData=
[
  ['tnfc_5fprotocol',['tNFC_PROTOCOL',['../linux__nfc__api_8h.html#a5bbdb860d0cd45c3077e27bbcf0abc5f',1,'linux_nfc_api.h']]]
];
