#include "ProviderConnector.h"

ProviderConnector::ProviderConnector()
{
}


ProviderConnector::~ProviderConnector()
{
}


