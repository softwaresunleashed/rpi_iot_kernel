

#include "Runnable.h"
#define VERBOSE_TAG "Runnable"
#include "core/Verbose.h"



Runnable::Runnable()
{
	
}

Runnable::~Runnable()
{
	
}

