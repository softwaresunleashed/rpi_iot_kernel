

#ifndef TYPES_H
#define TYPES_H

/** Standard int definitions **/
#include <stdint.h>

#define PTR2UINT(x)            (uintptr_t)x
#define UINT2PTR(x)            (void*)x

#endif // ndef TYPES_H
