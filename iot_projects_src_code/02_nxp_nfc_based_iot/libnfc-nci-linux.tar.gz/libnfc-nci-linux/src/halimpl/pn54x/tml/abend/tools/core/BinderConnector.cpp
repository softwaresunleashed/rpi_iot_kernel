#include "BinderConnector.h"

BinderConnector::BinderConnector(const char* url)
{
}


BinderConnector::~BinderConnector()
{
}


